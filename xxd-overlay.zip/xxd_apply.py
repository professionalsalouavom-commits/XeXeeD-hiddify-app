#!/usr/bin/env python3
"""Applies the XXD-VPN overlay on a checkout of the repo.
usage: python3 xxd_apply.py <overlay_dir>   (run from the repo root)"""
import os, re, shutil, sys, glob

ov = os.path.abspath(sys.argv[1]); repo = os.getcwd()
SPECIAL = {'replace_by_name', 'xxd_apply.py'}

# 1) files with a known path: copy as they are
for top in sorted(os.listdir(ov)):
    if top in SPECIAL: continue
    src = os.path.join(ov, top)
    if os.path.isdir(src):
        for root, _, files in os.walk(src):
            for f in files:
                s = os.path.join(root, f)
                d = os.path.join(repo, os.path.relpath(s, ov))
                os.makedirs(os.path.dirname(d), exist_ok=True)
                # an image with the same name and another extension (ic_launcher.webp vs .png) = "Duplicate resources"
                base, ext = os.path.splitext(d)
                if ext.lower() in ('.png', '.webp', '.jpg', '.jpeg'):
                    for other in ('.png', '.webp', '.jpg', '.jpeg'):
                        if other != ext.lower() and os.path.exists(base + other):
                            os.remove(base + other); print('removed duplicate', os.path.relpath(base + other, repo))
                shutil.copyfile(s, d)
                print('copied', os.path.relpath(d, repo))

# 2) files whose folder is unknown: find them by name inside lib/
bad = False
rb = os.path.join(ov, 'replace_by_name')
for f in sorted(os.listdir(rb)):
    hits = [p for p in glob.glob('lib/**/' + f, recursive=True)]
    if len(hits) != 1:
        print(f'ERROR: expected exactly one {f} in lib/, found {hits}'); bad = True; continue
    shutil.copyfile(os.path.join(rb, f), hits[0]); print('replaced', hits[0])
if bad: sys.exit(1)

# 2b) Android files are patched in place (the fork's own versions stay, only my lines change)
def patch(path, pairs, regexes=()):
    if not os.path.exists(path):
        print('WARNING: not found:', path); return
    t = open(path, encoding='utf-8').read(); o = t
    for a_, b_ in pairs: t = t.replace(a_, b_)
    for rx, rep, flags in regexes: t = re.sub(rx, rep, t, flags=flags)
    if t == o: print('WARNING: nothing changed in', path)
    else: print('patched', path)
    open(path, 'w', encoding='utf-8').write(t)

man = 'android/app/src/main/AndroidManifest.xml'
patch(man, [('android:label="Hiddify"', 'android:label="XXD-VPN"')])
# remove every deep-link filter (VIEW), so a profile cannot be imported from outside
t = open(man, encoding='utf-8').read()
t2 = re.sub(r'[ \t]*<intent-filter[^>]*>(?:(?!</intent-filter>).)*?android\.intent\.action\.VIEW(?:(?!</intent-filter>).)*?</intent-filter>[ \t]*\n?', '', t, flags=re.S)
if t2 != t: open(man, 'w', encoding='utf-8').write(t2); print('removed deep-link filters')
for g in ('android/app/build.gradle', 'android/app/build.gradle.kts'):
    if os.path.exists(g):
        patch(g, [], [(r'(applicationId\s*=?\s*)"app\.hiddify\.com"', r'\1"com.xxdvpn.app"', 0)])
patch('android/app/src/main/res/xml/shortcuts.xml', [('android:targetPackage="app.hiddify.com"', 'android:targetPackage="com.xxdvpn.app"')])
patch('android/app/src/main/res/values/colors.xml', [], [(r'(<color name="splash_background">)[^<]*(</color>)', r'\1#0A0E17\2', 0)])

# 3) my settings (GitHub Variables). Empty = keep the placeholder.
def setconst(path, name, value):
    if not value: print('WARNING: no value for', name); return
    s = open(path, encoding='utf-8').read()
    n = re.subn(r"(const %s = )'[^']*'" % name, lambda m: m.group(1) + "'" + value.replace("'", '') + "'", s)
    if n[1] != 1: print('ERROR: constant not found:', name); sys.exit(1)
    open(path, 'w', encoding='utf-8').write(n[0]); print('set', name)

e = os.environ.get
tok = 'lib/features/profile/xxd_token.dart'; lnk = 'lib/features/home/xxd_links.dart'
if e('XXD_CLIENT_PATH'):
    setconst(tok, 'xxdSubBase', 'https://%s/%s/' % (e('XXD_DOMAIN') or 'xxdvpn.duckdns.org', e('XXD_CLIENT_PATH').strip('/')))
else:
    print('WARNING: XXD_CLIENT_PATH is empty: tokens will NOT work')
setconst(lnk, 'xxdWhatsAppChannel', e('XXD_WHATSAPP_CHANNEL'))
setconst(lnk, 'xxdTelegramChannel', e('XXD_TELEGRAM_CHANNEL'))
setconst(lnk, 'xxdAdminWhatsApp', re.sub(r'\D', '', e('XXD_ADMIN_WHATSAPP') or ''))
setconst(lnk, 'xxdGithubRepo', e('XXD_GITHUB_REPO'))
print('overlay applied')
