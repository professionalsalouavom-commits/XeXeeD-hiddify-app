import 'package:shared_preferences/shared_preferences.dart';
import 'package:uuid/uuid.dart';

/// Device identifier of this installation: 32 hex characters, created once and kept.
/// It is shown on the home page and sent as the x-hwid header to the XXD-VPN server.
class XxdHwid {
  static const _key = 'xxd_hwid';
  static String? _cache;

  static Future<String> get() async {
    final cached = _cache;
    if (cached != null) return cached;
    final prefs = await SharedPreferences.getInstance();
    var value = prefs.getString(_key);
    if (value == null || value.isEmpty) {
      value = const Uuid().v4().replaceAll('-', '').toUpperCase();
      await prefs.setString(_key, value);
    }
    return _cache = value;
  }
}
