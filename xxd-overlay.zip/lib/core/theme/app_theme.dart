import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:hiddify/core/theme/app_theme_mode.dart';
import 'package:hiddify/core/theme/theme_extensions.dart';

// XXD-VPN palettes
const _xxdDarkBg = Color(0xFF0A0E17);
const _xxdDarkCard = Color(0xFF141B2D);
const _xxdAccent = Color(0xFF00E5FF);
const _xxdLightBg = Color(0xFFF4F7FB);

final ColorScheme _xxdDarkScheme = ColorScheme.fromSeed(seedColor: _xxdAccent, brightness: Brightness.dark).copyWith(
  primary: _xxdAccent,
  onPrimary: const Color(0xFF00131A),
  secondary: _xxdAccent,
  primaryContainer: const Color(0xFF0B3A44),
  onPrimaryContainer: _xxdAccent,
  secondaryContainer: _xxdDarkCard,
  surface: _xxdDarkBg,
  onSurface: Colors.white,
  surfaceContainerLowest: _xxdDarkBg,
  surfaceContainerLow: _xxdDarkCard,
  surfaceContainer: _xxdDarkCard,
  surfaceContainerHigh: _xxdDarkCard,
  surfaceContainerHighest: _xxdDarkCard,
);

final ColorScheme _xxdLightScheme = ColorScheme.fromSeed(seedColor: const Color(0xFF00A6C0)).copyWith(
  primary: const Color(0xFF0089A3),
  onPrimary: Colors.white,
  secondary: const Color(0xFF0089A3),
  primaryContainer: const Color(0xFFD3F4FB),
  onPrimaryContainer: const Color(0xFF00343F),
  secondaryContainer: const Color(0xFFE3EEF5),
  surface: _xxdLightBg,
  onSurface: const Color(0xFF0A0E17),
  surfaceContainerLowest: Colors.white,
  surfaceContainerLow: Colors.white,
  surfaceContainer: Colors.white,
  surfaceContainerHigh: const Color(0xFFEAF1F7),
  surfaceContainerHighest: const Color(0xFFEAF1F7),
);

class AppTheme {
  AppTheme(this.mode, this.fontFamily);
  final AppThemeMode mode;
  final String fontFamily;

  // XXD-VPN colors: the system / dynamic colors are ignored, the theme setting still picks light or dark.
  ThemeData lightTheme(ColorScheme? lightColorScheme) {
    return ThemeData(
      useMaterial3: true,
      colorScheme: _xxdLightScheme,
      scaffoldBackgroundColor: _xxdLightBg,
      fontFamily: fontFamily,
      appBarTheme: const AppBarTheme(backgroundColor: _xxdLightBg, surfaceTintColor: Colors.transparent),
      bottomSheetTheme: const BottomSheetThemeData(backgroundColor: Colors.white, surfaceTintColor: Colors.transparent),
      extensions: const <ThemeExtension<dynamic>>{ConnectionButtonTheme.light},
    );
  }

  ThemeData darkTheme(ColorScheme? darkColorScheme) {
    final bg = mode.trueBlack ? Colors.black : _xxdDarkBg;
    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      colorScheme: _xxdDarkScheme,
      scaffoldBackgroundColor: bg,
      fontFamily: fontFamily,
      appBarTheme: AppBarTheme(backgroundColor: bg, surfaceTintColor: Colors.transparent),
      bottomSheetTheme: const BottomSheetThemeData(backgroundColor: _xxdDarkCard, surfaceTintColor: Colors.transparent),
      extensions: const <ThemeExtension<dynamic>>{ConnectionButtonTheme.light},
    );
  }

  CupertinoThemeData cupertinoThemeData(bool sysDark, ColorScheme? lightColorScheme, ColorScheme? darkColorScheme) {
    final bool isDark = switch (mode) {
      AppThemeMode.system => sysDark,
      AppThemeMode.light => false,
      AppThemeMode.dark => true,
      AppThemeMode.black => true,
    };
    final def = CupertinoThemeData(brightness: isDark ? Brightness.dark : Brightness.light);
    // final def = CupertinoThemeData(brightness: Brightness.dark);

    // return def;
    final defaultMaterialTheme = isDark ? darkTheme(darkColorScheme) : lightTheme(lightColorScheme);
    return MaterialBasedCupertinoThemeData(
      materialTheme: defaultMaterialTheme.copyWith(
        cupertinoOverrideTheme: def.copyWith(
          textTheme: CupertinoTextThemeData(
            textStyle: def.textTheme.textStyle.copyWith(fontFamily: fontFamily),
            actionTextStyle: def.textTheme.actionTextStyle.copyWith(fontFamily: fontFamily),
            navActionTextStyle: def.textTheme.navActionTextStyle.copyWith(fontFamily: fontFamily),
            navTitleTextStyle: def.textTheme.navTitleTextStyle.copyWith(fontFamily: fontFamily),
            navLargeTitleTextStyle: def.textTheme.navLargeTitleTextStyle.copyWith(fontFamily: fontFamily),
            pickerTextStyle: def.textTheme.pickerTextStyle.copyWith(fontFamily: fontFamily),
            dateTimePickerTextStyle: def.textTheme.dateTimePickerTextStyle.copyWith(fontFamily: fontFamily),
            tabLabelTextStyle: def.textTheme.tabLabelTextStyle.copyWith(fontFamily: fontFamily),
          ).copyWith(),
          barBackgroundColor: def.barBackgroundColor,
          scaffoldBackgroundColor: def.scaffoldBackgroundColor,
        ),
      ),
    );
  }
}
