// XXD-VPN links - EDIT THESE 4 LINES
const xxdWhatsAppChannel = 'https://whatsapp.com/channel/YOUR_CHANNEL_CODE'; // your WhatsApp channel/group link
const xxdTelegramChannel = 'https://t.me/YOUR_TELEGRAM_CHANNEL'; // your Telegram channel link
const xxdAdminWhatsApp = '237XXXXXXXXX'; // admin number, digits only, with country code (Cameroon = 237)

bool xxdIsPlaceholder(String v) => v.contains('YOUR_') || v.contains('XXXX');

// My PUBLIC GitHub repo, "username/repository" (used for update checks and the announcement banner)
const xxdGithubRepo = 'YOUR_GITHUB_USER/YOUR_REPO';
const xxdAnnouncementUrl = 'https://raw.githubusercontent.com/$xxdGithubRepo/main/announcement.json';

// Hiddify Manager user API, appended to xxdSubBase (check Admin Panel -> Settings -> API for the exact path of your version)
const xxdAccountEndpoint = 'api/v2/user/me/';

// Operators shown to the customer, with words that appear in YOUR server names in the panel.
// Example: a server called "Orange-VLESS-1" is chosen when the customer picks Orange.
const xxdOperators = <String, List<String>>{
  'Orange': ['orange'],
  'MTN': ['mtn'],
  'Camtel': ['camtel', 'hy2', 'hysteria'],
};

// Plans list (plans.json at the root of my public GitHub repo, branch main)
const xxdPlansUrl = 'https://raw.githubusercontent.com/$xxdGithubRepo/main/plans.json';
