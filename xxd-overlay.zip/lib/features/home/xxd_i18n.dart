import 'package:flutter/widgets.dart';

/// XXD-VPN texts in French (default) and English.
/// The language follows the app language (Settings > General > Language).
bool xxdIsFrench(BuildContext context) => Localizations.localeOf(context).languageCode == 'fr';

/// Two versions of a text.
String xxd2(BuildContext context, String fr, String en) => xxdIsFrench(context) ? fr : en;

const _en = <String, String>{
  'Mon compte': 'My account',
  'Informations indisponibles': 'Information unavailable',
  "Vérifiez votre connexion ou contactez l'admin.": 'Check your connection or contact the admin.',
  'Réessayer': 'Retry',
  'Rafraîchir': 'Refresh',
  'Forfait expiré': 'Plan expired',
  'Renouveler': 'Renew',
  'Comment ça marche ?': 'How does it work?',
  'Fermer': 'Close',
  'Mon Identifiant XXD-VPN :': 'My XXD-VPN ID:',
  'Copié': 'Copied',
  'Copier': 'Copy',
  "Envoyer à l'admin (WhatsApp)": 'Send to admin (WhatsApp)',
  'Renouveler mon forfait': 'Renew my plan',
  'Passer': 'Skip',
  'Commencer': 'Start',
  'Suivant': 'Next',
  'Lien non configuré': 'Link not configured',
  "Impossible d'ouvrir le lien": 'Cannot open the link',
  'Inviter un ami': 'Invite a friend',
  'Importer un jeton': 'Import a token',
  'Coller': 'Paste',
  'Valider': 'Confirm',
  'Mon opérateur :': 'My operator:',
  'Auto': 'Auto',
};

/// One text: the French text is the key.
String xxd(BuildContext context, String fr) => xxdIsFrench(context) ? fr : (_en[fr] ?? fr);
