import 'package:flutter/material.dart';
import 'package:hiddify/features/home/xxd_i18n.dart';
import 'package:hiddify/core/http_client/xxd_hwid.dart';
import 'package:hiddify/features/home/xxd_links.dart';
import 'package:hiddify/features/home/xxd_support_buttons.dart';
import 'package:hiddify/features/profile/model/profile_entity.dart';
import 'package:hiddify/features/profile/notifier/active_profile_notifier.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

/// Warns when the active plan is expired, expires in less than 2 days, or has little data left.
class XxdExpiryBanner extends ConsumerWidget {
  const XxdExpiryBanner({super.key});

  static String _fmt(BuildContext context, Duration d) {
    if (d.inDays >= 1) return '${d.inDays} ${xxd2(context, 'jour(s)', 'day(s)')}';
    if (d.inHours >= 1) return '${d.inHours} h';
    return '${d.inMinutes.clamp(0, 59)} min';
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final profile = ref.watch(activeProfileProvider).value;
    if (profile is! RemoteProfileEntity) return const SizedBox.shrink();
    final info = profile.subInfo;
    if (info == null) return const SizedBox.shrink();

    String? message;
    var expired = false;
    // an expire date before the year 2000 means "no expiry"
    if (info.expire.year >= 2000) {
      if (info.isExpired) {
        message = xxd2(context, 'Votre forfait a expiré.', 'Your plan has expired.');
        expired = true;
      } else if (info.remaining < const Duration(days: 2)) {
        message = xxd2(context, 'Votre forfait expire dans ${_fmt(context, info.remaining)}.', 'Your plan expires in ${_fmt(context, info.remaining)}.');
      }
    }
    if (message == null && info.total > 0 && info.remainingBW <= 0) {
      message = xxd2(context, 'Votre data est épuisée.', 'Your data is used up.');
      expired = true;
    } else if (message == null && info.total > 0 && info.remainingBWratio < 0.1) {
      message = xxd2(context, 'Il reste moins de 10 % de votre data.', 'Less than 10% of your data is left.');
    }
    if (message == null) return const SizedBox.shrink();

    return Card(
      color: expired ? const Color(0xFF5A1620) : const Color(0xFF5A4316),
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Row(
          children: [
            Icon(expired ? Icons.error_outline_rounded : Icons.warning_amber_rounded),
            const SizedBox(width: 12),
            Expanded(child: Text(message)),
            const SizedBox(width: 8),
            TextButton(
              onPressed: () async {
                final hwid = await XxdHwid.get();
                if (!context.mounted) return;
                await xxdOpenLink(
                  context,
                  'https://wa.me/$xxdAdminWhatsApp?text=${Uri.encodeComponent(xxd2(context, 'Bonjour, je souhaite renouveler mon abonnement XXD-VPN. Mon identifiant : $hwid', 'Hello, I would like to renew my XXD-VPN subscription. My ID: $hwid'))}',
                );
              },
              child: Text(xxd(context, 'Renouveler')),
            ),
          ],
        ),
      ),
    );
  }
}
