import 'package:flutter/material.dart';
import 'package:hiddify/features/home/xxd_i18n.dart';
import 'package:hiddify/features/home/xxd_links.dart';
import 'package:hiddify/features/proxy/overview/proxies_overview_notifier.dart';
import 'package:hiddify/hiddifycore/generated/v2/hcore/hcore.pb.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

/// "Meilleur serveur": servers of each operator sorted by ping (the app's own automatic tests).
class XxdBestServerDialog extends ConsumerWidget {
  const XxdBestServerDialog({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final group = ref.watch(proxiesOverviewNotifierProvider).valueOrNull;
    return AlertDialog(
      title: Text(xxd2(context, 'Meilleur serveur', 'Best server')),
      content: group == null
          ? Text(xxd2(context, "Connectez-vous d'abord : les pings apparaissent une fois le VPN actif.", 'Connect first: pings appear once the VPN is on.'))
          : SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  for (final entry in xxdOperators.entries) ...[
                    Text(entry.key, style: Theme.of(context).textTheme.titleSmall),
                    ..._rows(context, ref, group, entry.value),
                    const SizedBox(height: 8),
                  ],
                ],
              ),
            ),
      actions: [TextButton(onPressed: () => Navigator.of(context).pop(), child: Text(xxd(context, 'Fermer')))],
    );
  }

  List<Widget> _rows(BuildContext context, WidgetRef ref, OutboundGroup group, List<String> keywords) {
    final items = group.items
        .where((OutboundInfo e) => !e.isGroup && keywords.any((k) => e.tag.toLowerCase().contains(k.toLowerCase())))
        .toList()
      ..sort((a, b) {
        // untested or failed pings (0 / very large) go last
        int rank(OutboundInfo x) => (x.urlTestDelay <= 0 || x.urlTestDelay >= 65000) ? 1 << 30 : x.urlTestDelay;
        return rank(a).compareTo(rank(b));
      });
    if (items.isEmpty) return [Text(xxd2(context, 'Aucun serveur trouvé', 'No server found'))];
    return [
      for (final e in items.take(3))
        ListTile(
          dense: true,
          contentPadding: EdgeInsets.zero,
          title: Text(e.tag),
          subtitle: Text((e.urlTestDelay <= 0 || e.urlTestDelay >= 65000) ? xxd2(context, 'ping non testé', 'ping not tested') : '${e.urlTestDelay} ms'),
          trailing: group.selected == e.tag
              ? const Icon(Icons.check_circle_rounded)
              : TextButton(
                  onPressed: () {
                    ref.read(proxiesOverviewNotifierProvider.notifier).changeProxy(group.tag, e.tag);
                    Navigator.of(context).pop();
                  },
                  child: Text(xxd2(context, 'Utiliser', 'Use')),
                ),
        ),
    ];
  }
}
