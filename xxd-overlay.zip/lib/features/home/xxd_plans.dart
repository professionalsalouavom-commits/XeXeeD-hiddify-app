import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:hiddify/core/http_client/xxd_hwid.dart';
import 'package:hiddify/features/home/xxd_i18n.dart';
import 'package:hiddify/features/home/xxd_links.dart';
import 'package:hiddify/features/home/xxd_support_buttons.dart';

Future<Map<String, dynamic>?> _loadPlans() async {
  if (xxdIsPlaceholder(xxdGithubRepo)) return null;
  final client = HttpClient()..connectionTimeout = const Duration(seconds: 10);
  try {
    final request = await client.getUrl(Uri.parse(xxdPlansUrl));
    final response = await request.close().timeout(const Duration(seconds: 15));
    if (response.statusCode != 200) return null;
    final data = jsonDecode(await response.transform(utf8.decoder).join());
    return data is Map<String, dynamic> ? data : null;
  } catch (_) {
    return null;
  } finally {
    client.close();
  }
}

Future<void> _whatsApp(BuildContext context, String fr, String en) async {
  final hwid = await XxdHwid.get();
  if (!context.mounted) return;
  final text = xxd2(context, '$fr Mon identifiant : $hwid', '$en My ID: $hwid');
  await xxdOpenLink(context, 'https://wa.me/$xxdAdminWhatsApp?text=${Uri.encodeComponent(text)}');
}

/// "Essai gratuit": a WhatsApp message to the admin asking for a trial.
Future<void> xxdRequestTrial(BuildContext context) =>
    _whatsApp(context, 'Bonjour, je voudrais un essai gratuit XXD-VPN.', 'Hello, I would like a free XXD-VPN trial.');

void xxdShowPlans(BuildContext context) {
  showModalBottomSheet<void>(context: context, isScrollControlled: true, builder: (_) => const _PlansSheet());
}

class _PlansSheet extends StatefulWidget {
  const _PlansSheet();

  @override
  State<_PlansSheet> createState() => _PlansSheetState();
}

class _PlansSheetState extends State<_PlansSheet> {
  final _future = _loadPlans();

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: FutureBuilder<Map<String, dynamic>?>(
          future: _future,
          builder: (context, snapshot) {
            if (snapshot.connectionState != ConnectionState.done) {
              return const SizedBox(height: 160, child: Center(child: CircularProgressIndicator()));
            }
            final data = snapshot.data;
            final plans = (data?['plans'] as List?)?.whereType<Map>().toList() ?? const [];
            if (plans.isEmpty) {
              return Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(xxd2(context, 'Tarifs indisponibles pour le moment.', 'Plans unavailable right now.'), style: theme.textTheme.titleMedium),
                  const SizedBox(height: 12),
                  FilledButton(
                    onPressed: () => _whatsApp(context, 'Bonjour, quels sont vos tarifs XXD-VPN ?', 'Hello, what are your XXD-VPN prices?'),
                    child: Text(xxd2(context, 'Demander les tarifs (WhatsApp)', 'Ask for prices (WhatsApp)')),
                  ),
                ],
              );
            }
            final payment = '${(xxdIsFrench(context) ? data!['payment'] : (data!['payment_en'] ?? data['payment'])) ?? ''}';
            return SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(xxd2(context, 'Nos forfaits', 'Our plans'), style: theme.textTheme.titleLarge),
                  const SizedBox(height: 12),
                  for (final p in plans)
                    Card(
                      child: ListTile(
                        title: Text('${xxdIsFrench(context) ? p['name'] : (p['name_en'] ?? p['name'])}'),
                        subtitle: Text(
                          [
                            if (p['price'] != null) '${p['price']}',
                            if (p['days'] != null) '${p['days']} ${xxd2(context, 'jours', 'days')}',
                            if (p['gb'] != null) '${p['gb']}',
                          ].join('  ·  '),
                        ),
                        trailing: FilledButton.tonal(
                          onPressed: () {
                            final name = '${p['name']} (${p['price'] ?? ''})';
                            _whatsApp(context, 'Bonjour, je veux le forfait $name.', 'Hello, I want the plan $name.');
                          },
                          child: Text(xxd2(context, 'Choisir', 'Choose')),
                        ),
                      ),
                    ),
                  if (payment.isNotEmpty) ...[
                    const SizedBox(height: 8),
                    Text(payment),
                  ],
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}
