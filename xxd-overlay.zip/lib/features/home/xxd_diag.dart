import 'dart:io';

import 'package:flutter/material.dart';
import 'package:hiddify/core/http_client/xxd_hwid.dart';
import 'package:hiddify/features/home/xxd_i18n.dart';
import 'package:hiddify/features/home/xxd_links.dart';
import 'package:hiddify/features/home/xxd_support_buttons.dart';
import 'package:hiddify/features/profile/model/profile_entity.dart';
import 'package:hiddify/features/profile/notifier/active_profile_notifier.dart';
import 'package:hiddify/features/profile/xxd_token.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

class _Check {
  const _Check(this.ok, this.title, this.detail);
  final bool? ok; // null = not applicable
  final String title;
  final String detail;
}

Future<int?> _status(String url, Map<String, String> headers) async {
  final client = HttpClient()..connectionTimeout = const Duration(seconds: 10);
  try {
    final request = await client.getUrl(Uri.parse(url));
    headers.forEach(request.headers.set);
    final response = await request.close().timeout(const Duration(seconds: 15));
    await response.drain<void>();
    return response.statusCode;
  } catch (_) {
    return null;
  } finally {
    client.close();
  }
}

/// "Problème de connexion ?": quick checks (internet, server, token, plan) + a message to the admin.
class XxdDiagDialog extends ConsumerStatefulWidget {
  const XxdDiagDialog({super.key});

  @override
  ConsumerState<XxdDiagDialog> createState() => _XxdDiagDialogState();
}

class _XxdDiagDialogState extends ConsumerState<XxdDiagDialog> {
  List<_Check>? _checks;
  String _hwid = '';

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _run());
  }

  Future<void> _run() async {
    final fr = xxdIsFrench(context);
    String t(String f, String e) => fr ? f : e;
    final profile = ref.read(activeProfileProvider).value;
    final hwid = await XxdHwid.get();
    final checks = <_Check>[];

    // 1. internet
    try {
      final r = await InternetAddress.lookup('one.one.one.one').timeout(const Duration(seconds: 8));
      checks.add(_Check(r.isNotEmpty, 'Internet', r.isNotEmpty ? t('Connecté', 'Connected') : t("Pas d'accès à Internet", 'No internet access')));
    } catch (_) {
      checks.add(_Check(false, 'Internet', t("Pas d'accès à Internet", 'No internet access')));
    }

    // 2. server
    final host = Uri.parse(xxdSubBase).host;
    final serverStatus = await _status('https://$host/', const {});
    checks.add(_Check(serverStatus != null, t('Serveur', 'Server'), serverStatus != null ? t('Joignable', 'Reachable') : t('Injoignable', 'Unreachable')));

    // 3. token
    if (profile is RemoteProfileEntity && isXxdUrl(profile.url)) {
      final code = await _status(profile.url, {'x-hwid': hwid, 'user-agent': 'XXD-VPN'});
      final ok = code == 200;
      checks.add(_Check(
        code == null ? null : ok,
        t('Jeton', 'Token'),
        code == null
            ? t('Non vérifié (serveur injoignable)', 'Not checked (server unreachable)')
            : ok
            ? t('Accepté', 'Accepted')
            : t('Refusé (HTTP $code) : jeton invalide, expiré ou appareil non autorisé', 'Refused (HTTP $code): invalid or expired token, or device not allowed'),
      ));
      final info = profile.subInfo;
      if (info != null) {
        final expiredByDate = info.expire.year >= 2000 && info.isExpired;
        final noData = info.total > 0 && info.remainingBW <= 0;
        checks.add(_Check(
          !(expiredByDate || noData),
          t('Forfait', 'Plan'),
          expiredByDate
              ? t('Expiré', 'Expired')
              : noData
              ? t('Data épuisée', 'Data used up')
              : t('Actif', 'Active'),
        ));
      }
    } else {
      checks.add(_Check(false, t('Jeton', 'Token'), t('Aucun jeton importé', 'No token imported')));
    }
    if (!mounted) return;
    setState(() {
      _hwid = hwid;
      _checks = checks;
    });
  }

  @override
  Widget build(BuildContext context) {
    final checks = _checks;
    return AlertDialog(
      title: Text(xxd2(context, 'Problème de connexion ?', 'Connection problem?')),
      content: checks == null
          ? const SizedBox(height: 100, child: Center(child: CircularProgressIndicator()))
          : Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                for (final c in checks)
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 4),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Icon(
                          c.ok == null ? Icons.help_outline_rounded : (c.ok! ? Icons.check_circle_rounded : Icons.cancel_rounded),
                          color: c.ok == null ? null : (c.ok! ? Colors.green : Colors.redAccent),
                        ),
                        const SizedBox(width: 10),
                        Expanded(child: Text('${c.title} : ${c.detail}')),
                      ],
                    ),
                  ),
              ],
            ),
      actions: [
        TextButton(onPressed: () => Navigator.of(context).pop(), child: Text(xxd(context, 'Fermer'))),
        if (checks != null)
          FilledButton(
            onPressed: () {
              final lines = checks.map((c) => '${c.ok == null ? '?' : (c.ok! ? 'OK' : 'KO')} ${c.title}: ${c.detail}').join('\n');
              final text = xxd2(context, 'Diagnostic XXD-VPN\n$lines\nMon identifiant : $_hwid', 'XXD-VPN diagnostic\n$lines\nMy ID: $_hwid');
              xxdOpenLink(context, 'https://wa.me/$xxdAdminWhatsApp?text=${Uri.encodeComponent(text)}');
            },
            child: Text(xxd2(context, "Envoyer à l'admin", 'Send to admin')),
          ),
      ],
    );
  }
}
