import 'package:flutter/material.dart';
import 'package:hiddify/features/home/xxd_i18n.dart';
import 'package:flutter/services.dart';
import 'package:hiddify/core/http_client/xxd_hwid.dart';
import 'package:hiddify/features/home/xxd_links.dart';
import 'package:hiddify/features/home/xxd_support_buttons.dart';

/// "Mon Identifiant XXD-VPN" with a Copy button.
class XxdHwidCard extends StatelessWidget {
  const XxdHwidCard({super.key});

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<String>(
      future: XxdHwid.get(),
      builder: (context, snapshot) {
        final hwid = snapshot.data ?? '...';
        return Card(
          margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              children: [
                Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(xxd(context, 'Mon Identifiant XXD-VPN :')),
                      const SizedBox(height: 4),
                      SelectableText(hwid, style: const TextStyle(fontWeight: FontWeight.bold)),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                FilledButton(
                  onPressed: snapshot.hasData
                      ? () async {
                          await Clipboard.setData(ClipboardData(text: hwid));
                          if (context.mounted) {
                            ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(xxd(context, 'Copié'))));
                          }
                        }
                      : null,
                  child: Text(xxd(context, 'Copier')),
                ),
              ],
            ),
                const SizedBox(height: 8),
                SizedBox(
                  width: double.infinity,
                  child: OutlinedButton.icon(
                    icon: const Icon(Icons.chat_rounded),
                    label: Text(xxd(context, "Envoyer à l'admin (WhatsApp)")),
                    onPressed: snapshot.hasData
                        ? () => xxdOpenLink(
                              context,
                              'https://wa.me/$xxdAdminWhatsApp?text=${Uri.encodeComponent(xxd2(context, 'Bonjour, voici mon identifiant XXD-VPN : $hwid', 'Hello, here is my XXD-VPN ID: $hwid'))}',
                            )
                        : null,
                  ),
                ),
                const SizedBox(height: 8),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton.tonalIcon(
                    icon: const Icon(Icons.autorenew_rounded),
                    label: Text(xxd(context, 'Renouveler mon forfait')),
                    onPressed: snapshot.hasData
                        ? () => xxdOpenLink(
                              context,
                              'https://wa.me/$xxdAdminWhatsApp?text=${Uri.encodeComponent(xxd2(context, 'Bonjour, je souhaite renouveler mon abonnement XXD-VPN. Mon identifiant : $hwid', 'Hello, I would like to renew my XXD-VPN subscription. My ID: $hwid'))}',
                            )
                        : null,
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
