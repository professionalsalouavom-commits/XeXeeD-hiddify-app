import 'package:flutter/material.dart';
import 'package:hiddify/core/http_client/xxd_hwid.dart';
import 'package:hiddify/features/home/xxd_account.dart';
import 'package:hiddify/features/home/xxd_best_server.dart';
import 'package:hiddify/features/home/xxd_diag.dart';
import 'package:hiddify/features/home/xxd_lock.dart';
import 'package:hiddify/features/home/xxd_howto.dart';
import 'package:hiddify/features/home/xxd_i18n.dart';
import 'package:hiddify/features/home/xxd_links.dart';
import 'package:hiddify/features/home/xxd_plans.dart';
import 'package:url_launcher/url_launcher.dart';

Future<void> xxdOpenLink(BuildContext context, String url) async {
  final messenger = ScaffoldMessenger.of(context);
  if (xxdIsPlaceholder(url)) {
    messenger.showSnackBar(SnackBar(content: Text(xxd(context, 'Lien non configuré'))));
    return;
  }
  final ok = await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
  if (!ok) messenger.showSnackBar(SnackBar(content: Text(xxd(context, "Impossible d'ouvrir le lien"))));
}

enum _More { diag, best, howto, invite, trial, lock }

/// WhatsApp channel + Telegram channel buttons, then "Mon compte", "Tarifs" and a "Plus" menu.
class XxdSupportButtons extends StatelessWidget {
  const XxdSupportButtons({super.key});

  Future<void> _invite(BuildContext context) async {
    if (xxdIsPlaceholder(xxdWhatsAppChannel)) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(xxd(context, 'Lien non configuré'))));
      return;
    }
    final code = (await XxdHwid.get()).substring(0, 8);
    if (!context.mounted) return;
    final text = xxd2(
      context,
      "Salut ! J'utilise XXD-VPN pour me connecter vite et en sécurité. Rejoins notre chaîne : $xxdWhatsAppChannel\nCode parrain : $code (donne-le à l'admin)",
      'Hi! I use XXD-VPN to connect fast and safely. Join our channel: $xxdWhatsAppChannel\nReferral code: $code (give it to the admin)',
    );
    await xxdOpenLink(context, 'https://wa.me/?text=${Uri.encodeComponent(text)}');
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            children: [
              Expanded(
                child: FilledButton.icon(
                  style: FilledButton.styleFrom(backgroundColor: const Color(0xFF1B8F4B), foregroundColor: Colors.white),
                  icon: const Icon(Icons.chat_rounded),
                  label: const Text('WhatsApp'),
                  onPressed: () => xxdOpenLink(context, xxdWhatsAppChannel),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: FilledButton.icon(
                  style: FilledButton.styleFrom(backgroundColor: const Color(0xFF229ED9), foregroundColor: Colors.white),
                  icon: const Icon(Icons.send_rounded),
                  label: const Text('Telegram'),
                  onPressed: () => xxdOpenLink(context, xxdTelegramChannel),
                ),
              ),
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const XxdAccountButton(),
              TextButton.icon(
                icon: const Icon(Icons.sell_rounded),
                label: Text(xxd2(context, 'Tarifs', 'Plans')),
                onPressed: () => xxdShowPlans(context),
              ),
              PopupMenuButton<_More>(
                tooltip: xxd2(context, 'Plus', 'More'),
                icon: const Icon(Icons.more_horiz_rounded),
                onSelected: (value) => switch (value) {
                  _More.diag => showDialog<void>(context: context, builder: (_) => const XxdDiagDialog()),
                  _More.best => showDialog<void>(context: context, builder: (_) => const XxdBestServerDialog()),
                  _More.howto => xxdShowHowTo(context),
                  _More.invite => _invite(context),
                  _More.trial => xxdRequestTrial(context),
                  _More.lock => xxdShowLockSettings(context),
                },
                itemBuilder: (context) => [
                  PopupMenuItem(value: _More.diag, child: Text(xxd2(context, 'Problème de connexion ?', 'Connection problem?'))),
                  PopupMenuItem(value: _More.best, child: Text(xxd2(context, 'Meilleur serveur', 'Best server'))),
                  PopupMenuItem(value: _More.howto, child: Text(xxd(context, 'Comment ça marche ?'))),
                  PopupMenuItem(value: _More.invite, child: Text(xxd(context, 'Inviter un ami'))),
                  PopupMenuItem(value: _More.trial, child: Text(xxd2(context, 'Essai gratuit', 'Free trial'))),
                  PopupMenuItem(value: _More.lock, child: Text(xxd2(context, 'Verrouillage par PIN', 'PIN lock'))),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }
}
