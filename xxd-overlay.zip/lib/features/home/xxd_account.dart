import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:hiddify/features/home/xxd_i18n.dart';
import 'package:hiddify/features/home/xxd_links.dart';
import 'package:hiddify/features/profile/model/profile_entity.dart';
import 'package:hiddify/features/profile/notifier/active_profile_notifier.dart';
import 'package:hiddify/features/profile/xxd_token.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

/// "Mon compte" button: shows plan, expiry and data read from the Hiddify Manager user API.
class XxdAccountButton extends ConsumerWidget {
  const XxdAccountButton({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return TextButton.icon(
      icon: const Icon(Icons.account_circle_rounded),
      label: Text(xxd(context, 'Mon compte')),
      onPressed: () {
        final profile = ref.read(activeProfileProvider).value;
        String? uuid;
        if (profile is RemoteProfileEntity && isXxdUrl(profile.url)) {
          uuid = profile.url.substring(xxdSubBase.length).split('/').first;
        }
        showModalBottomSheet<void>(
          context: context,
          isScrollControlled: true,
          builder: (_) => _AccountSheet(uuid: uuid),
        );
      },
    );
  }
}

class _AccountSheet extends StatefulWidget {
  const _AccountSheet({required this.uuid});
  final String? uuid;

  @override
  State<_AccountSheet> createState() => _AccountSheetState();
}

class _AccountSheetState extends State<_AccountSheet> {
  Future<Map<String, dynamic>>? _future;

  @override
  void initState() {
    super.initState();
    _reload();
  }

  void _reload() {
    final uuid = widget.uuid;
    _future = uuid == null ? Future.error('no profile') : _fetch(uuid);
  }

  static Future<Map<String, dynamic>> _fetch(String uuid) async {
    final client = HttpClient()..connectionTimeout = const Duration(seconds: 10);
    try {
      final request = await client.getUrl(Uri.parse('$xxdSubBase$xxdAccountEndpoint'));
      request.headers.set('Hiddify-API-Key', uuid);
      request.headers.set('Accept', 'application/json');
      final response = await request.close().timeout(const Duration(seconds: 15));
      if (response.statusCode != 200) throw HttpException('HTTP ${response.statusCode}');
      final data = jsonDecode(await response.transform(utf8.decoder).join());
      if (data is Map<String, dynamic>) return data;
      throw const FormatException('unexpected format');
    } finally {
      client.close();
    }
  }

  static double? _num(dynamic v) => v == null ? null : double.tryParse('$v');

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: FutureBuilder<Map<String, dynamic>>(
          future: _future,
          builder: (context, snapshot) {
            if (snapshot.connectionState != ConnectionState.done) {
              return const SizedBox(height: 160, child: Center(child: CircularProgressIndicator()));
            }
            if (snapshot.hasError) {
              return Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(xxd(context, 'Informations indisponibles'), style: theme.textTheme.titleMedium),
                  const SizedBox(height: 8),
                  Text(xxd(context, "Vérifiez votre connexion ou contactez l'admin."), textAlign: TextAlign.center),
                  const SizedBox(height: 12),
                  FilledButton(onPressed: () => setState(_reload), child: Text(xxd(context, 'Réessayer'))),
                ],
              );
            }
            final d = snapshot.data!;
            final used = _num(d['current_usage_GB']) ?? 0;
            final limit = _num(d['usage_limit_GB']) ?? 0;
            final days = _num(d['package_days'])?.toInt();
            final start = DateTime.tryParse('${d['start_date'] ?? ''}');
            DateTime? expiry;
            if (start != null && days != null) expiry = start.add(Duration(days: days));
            final left = expiry?.difference(DateTime.now());
            return Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('${d['name'] ?? xxd(context, 'Mon compte')}', style: theme.textTheme.titleLarge),
                const SizedBox(height: 16),
                Text('Data : ${used.toStringAsFixed(2)} / ${limit > 0 ? '${limit.toStringAsFixed(0)} ${xxd2(context, 'Go', 'GB')}' : xxd2(context, 'Illimité', 'Unlimited')}'),
                if (limit > 0) ...[
                  const SizedBox(height: 8),
                  LinearProgressIndicator(value: (used / limit).clamp(0.0, 1.0), minHeight: 8),
                ],
                const SizedBox(height: 16),
                if (expiry != null)
                  Text(
                    left!.isNegative
                        ? xxd(context, 'Forfait expiré')
                        : '${xxd2(context, 'Expire le', 'Expires on')} ${expiry.day.toString().padLeft(2, '0')}/${expiry.month.toString().padLeft(2, '0')}/${expiry.year}'
                              '  (${left.inDays} ${xxd2(context, 'jour(s) restants', 'day(s) left')})',
                  ),
                if ('${d['last_online'] ?? ''}'.isNotEmpty) ...[
                  const SizedBox(height: 8),
                  Text('${xxd2(context, 'Dernière connexion', 'Last connection')} : ${d['last_online']}'),
                ],
                const SizedBox(height: 16),
                Align(
                  alignment: Alignment.centerRight,
                  child: TextButton(onPressed: () => setState(_reload), child: Text(xxd(context, 'Rafraîchir'))),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}
