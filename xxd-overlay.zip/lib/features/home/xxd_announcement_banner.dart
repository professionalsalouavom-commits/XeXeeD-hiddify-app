import 'dart:convert';

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:hiddify/core/http_client/http_client_provider.dart';
import 'package:hiddify/features/home/xxd_i18n.dart';
import 'package:hiddify/features/home/xxd_links.dart';
import 'package:hiddify/features/home/xxd_support_buttons.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

/// Shows the message of announcement.json (in my GitHub repo), when "enabled" is true.
/// {"enabled": true, "message": "Maintenance ce soir", "url": ""}
class XxdAnnouncementBanner extends HookConsumerWidget {
  const XxdAnnouncementBanner({super.key});

  Future<Map<String, dynamic>?> _load(WidgetRef ref) async {
    if (xxdIsPlaceholder(xxdGithubRepo)) return null;
    try {
      final response = await ref
          .read(httpClientProvider)
          .get<String>(xxdAnnouncementUrl, responseType: ResponseType.plain);
      final data = jsonDecode(response.data ?? '');
      if (data is Map<String, dynamic> && data['enabled'] == true && (data['message'] as String? ?? '').isNotEmpty) {
        return data;
      }
    } catch (_) {}
    return null;
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final dismissed = useState(false);
    final snapshot = useFuture(useMemoized(() => _load(ref)));
    final data = snapshot.data;
    if (dismissed.value || data == null) return const SizedBox.shrink();
    final url = data['url'] as String? ?? '';
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: ListTile(
        leading: const Icon(Icons.campaign_rounded),
        title: Text((xxdIsFrench(context) ? data['message'] : (data['message_en'] ?? data['message'])) as String),
        onTap: url.isEmpty ? null : () => xxdOpenLink(context, url),
        trailing: IconButton(icon: const Icon(Icons.close_rounded), onPressed: () => dismissed.value = true),
      ),
    );
  }
}
