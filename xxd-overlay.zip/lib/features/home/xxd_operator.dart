import 'package:flutter/material.dart';
import 'package:hiddify/features/home/xxd_i18n.dart';
import 'package:hiddify/features/home/xxd_links.dart';
import 'package:hiddify/features/proxy/overview/proxies_overview_notifier.dart';
import 'package:hiddify/hiddifycore/generated/v2/hcore/hcore.pb.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// The operator chosen by the customer ('' = automatic).
class XxdOperatorNotifier extends Notifier<String> {
  static const _key = 'xxd_operator';

  @override
  String build() {
    _load();
    return '';
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    state = prefs.getString(_key) ?? '';
  }

  Future<void> select(String operator) async {
    state = operator;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_key, operator);
  }
}

final xxdOperatorProvider = NotifierProvider<XxdOperatorNotifier, String>(XxdOperatorNotifier.new);

/// Chips "Orange / MTN / Camtel / Auto". Once the VPN is connected, the server whose name
/// contains the operator keywords (see xxdOperators in xxd_links.dart) is selected, once per connection.
class XxdOperatorPicker extends ConsumerStatefulWidget {
  const XxdOperatorPicker({super.key});

  @override
  ConsumerState<XxdOperatorPicker> createState() => _XxdOperatorPickerState();
}

class _XxdOperatorPickerState extends ConsumerState<XxdOperatorPicker> {
  bool _applied = false;

  void _apply() {
    final operator = ref.read(xxdOperatorProvider);
    final group = ref.read(proxiesOverviewNotifierProvider).valueOrNull;
    if (group == null) {
      _applied = false; // disconnected: apply again at the next connection
      return;
    }
    if (_applied || operator.isEmpty) return;
    final keywords = xxdOperators[operator];
    if (keywords == null) return;
    final matches = group.items
        .where((OutboundInfo e) => !e.isGroup && keywords.any((k) => e.tag.toLowerCase().contains(k.toLowerCase())))
        .toList();
    if (matches.isEmpty) return;
    _applied = true;
    final target = matches.firstWhere((e) => e.urlTestDelay > 0, orElse: () => matches.first);
    if (group.selected != target.tag) {
      ref.read(proxiesOverviewNotifierProvider.notifier).changeProxy(group.tag, target.tag);
    }
  }

  @override
  Widget build(BuildContext context) {
    final operator = ref.watch(xxdOperatorProvider);
    ref.listen(proxiesOverviewNotifierProvider, (previous, next) => _apply());
    ref.listen(xxdOperatorProvider, (previous, next) {
      _applied = false;
      _apply();
    });
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      child: Row(
        children: [
          Text(xxd(context, 'Mon opérateur :')),
          const SizedBox(width: 8),
          Expanded(
            child: Wrap(
              spacing: 6,
              children: [
                for (final name in [...xxdOperators.keys, ''])
                  ChoiceChip(
                    label: Text(name.isEmpty ? xxd(context, 'Auto') : name),
                    selected: operator == name,
                    onSelected: (_) => ref.read(xxdOperatorProvider.notifier).select(name),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
