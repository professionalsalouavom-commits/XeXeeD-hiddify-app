import 'package:flutter/material.dart';
import 'package:hiddify/features/home/xxd_i18n.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Simple PIN lock (4 to 6 digits). It deters casual use of a borrowed phone; it is not bank-level security.
class XxdLock {
  static const _key = 'xxd_pin';
  static bool unlocked = false;

  static int _hash(String pin) {
    var h = 0x811C9DC5;
    for (final c in 'xxd|$pin|vpn'.codeUnits) {
      h ^= c;
      h = (h * 0x01000193) & 0xFFFFFFFF;
    }
    return h;
  }

  static Future<bool> hasPin() async => (await SharedPreferences.getInstance()).containsKey(_key);

  static Future<void> setPin(String pin) async => (await SharedPreferences.getInstance()).setInt(_key, _hash(pin));

  static Future<void> clear() async => (await SharedPreferences.getInstance()).remove(_key);

  static Future<bool> check(String pin) async => (await SharedPreferences.getInstance()).getInt(_key) == _hash(pin);
}

/// Put once on the home page: asks the PIN when the app starts (if a PIN is set).
class XxdLockGate extends StatefulWidget {
  const XxdLockGate({super.key});

  @override
  State<XxdLockGate> createState() => _XxdLockGateState();
}

class _XxdLockGateState extends State<XxdLockGate> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      if (XxdLock.unlocked || !await XxdLock.hasPin() || !mounted) return;
      await showDialog<void>(
        context: context,
        barrierDismissible: false,
        builder: (_) => const PopScope(canPop: false, child: _PinDialog()),
      );
    });
  }

  @override
  Widget build(BuildContext context) => const SizedBox.shrink();
}

class _PinDialog extends StatefulWidget {
  const _PinDialog();

  @override
  State<_PinDialog> createState() => _PinDialogState();
}

class _PinDialogState extends State<_PinDialog> {
  final _controller = TextEditingController();
  String? _error;

  Future<void> _submit() async {
    if (await XxdLock.check(_controller.text)) {
      XxdLock.unlocked = true;
      if (mounted) Navigator.of(context).pop();
    } else {
      setState(() => _error = xxd2(context, 'PIN incorrect', 'Wrong PIN'));
      _controller.clear();
    }
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(xxd2(context, 'Entrez votre PIN', 'Enter your PIN')),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          TextField(
            controller: _controller,
            autofocus: true,
            obscureText: true,
            keyboardType: TextInputType.number,
            maxLength: 6,
            decoration: InputDecoration(errorText: _error, counterText: ''),
            onSubmitted: (_) => _submit(),
          ),
          const SizedBox(height: 8),
          Text(
            xxd2(context, "PIN oublié ? Effacez les données de l'application dans les réglages Android, puis ré-importez votre jeton.", 'Forgot the PIN? Clear the app data in Android settings, then import your token again.'),
            style: Theme.of(context).textTheme.bodySmall,
          ),
        ],
      ),
      actions: [FilledButton(onPressed: _submit, child: Text(xxd(context, 'Valider')))],
    );
  }
}

/// Dialog to set, change or remove the PIN.
Future<void> xxdShowLockSettings(BuildContext context) async {
  final has = await XxdLock.hasPin();
  if (!context.mounted) return;
  final controller = TextEditingController();
  await showDialog<void>(
    context: context,
    builder: (context) => AlertDialog(
      title: Text(xxd2(context, 'Verrouillage par PIN', 'PIN lock')),
      content: TextField(
        controller: controller,
        obscureText: true,
        keyboardType: TextInputType.number,
        maxLength: 6,
        decoration: InputDecoration(labelText: xxd2(context, 'Nouveau PIN (4 à 6 chiffres)', 'New PIN (4 to 6 digits)')),
      ),
      actions: [
        if (has)
          TextButton(
            onPressed: () async {
              await XxdLock.clear();
              if (context.mounted) Navigator.of(context).pop();
            },
            child: Text(xxd2(context, 'Désactiver', 'Turn off')),
          ),
        TextButton(onPressed: () => Navigator.of(context).pop(), child: Text(xxd(context, 'Fermer'))),
        FilledButton(
          onPressed: () async {
            final pin = controller.text.trim();
            if (!RegExp(r'^\d{4,6}$').hasMatch(pin)) return;
            await XxdLock.setPin(pin);
            XxdLock.unlocked = true;
            if (context.mounted) Navigator.of(context).pop();
          },
          child: Text(xxd2(context, 'Enregistrer', 'Save')),
        ),
      ],
    ),
  );
}
