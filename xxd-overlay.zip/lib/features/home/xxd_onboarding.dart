import 'package:flutter/material.dart';
import 'package:hiddify/features/home/xxd_i18n.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Shows a 3-slide welcome the first time the app is opened.
class XxdOnboarding extends StatefulWidget {
  const XxdOnboarding({super.key});

  @override
  State<XxdOnboarding> createState() => _XxdOnboardingState();
}

class _XxdOnboardingState extends State<XxdOnboarding> {
  static const _key = 'xxd_onboarded';

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _maybeShow());
  }

  Future<void> _maybeShow() async {
    final prefs = await SharedPreferences.getInstance();
    if (prefs.getBool(_key) ?? false) return;
    if (!mounted) return;
    await showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (_) => const _OnboardingDialog(),
    );
    await prefs.setBool(_key, true);
  }

  @override
  Widget build(BuildContext context) => const SizedBox.shrink();
}

class _OnboardingDialog extends StatefulWidget {
  const _OnboardingDialog();

  @override
  State<_OnboardingDialog> createState() => _OnboardingDialogState();
}

class _OnboardingDialogState extends State<_OnboardingDialog> {
  final _controller = PageController();
  int _index = 0;

  static List<(IconData, String, String)> _slides(BuildContext context) => [
    (
      Icons.shield_rounded,
      xxd2(context, 'Bienvenue sur XXD-VPN', 'Welcome to XXD-VPN'),
      xxd2(context, 'Une connexion rapide et sécurisée, en quelques secondes.', 'A fast and secure connection in seconds.'),
    ),
    (
      Icons.fingerprint_rounded,
      xxd2(context, 'Votre identifiant', 'Your ID'),
      xxd2(
        context,
        "Copiez votre identifiant sur l'écran d'accueil et envoyez-le à l'admin pour recevoir votre jeton.",
        'Copy your ID on the home screen and send it to the admin to receive your token.',
      ),
    ),
    (
      Icons.vpn_key_rounded,
      xxd2(context, 'Votre jeton', 'Your token'),
      xxd2(
        context,
        'Ajoutez un profil, collez le jeton reçu puis appuyez sur le grand bouton pour vous connecter.',
        'Add a profile, paste the token you received, then tap the big button to connect.',
      ),
    ),
  ];

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final slides = _slides(context);
    final last = _index == slides.length - 1;
    return Dialog(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            SizedBox(
              height: 250,
              child: PageView(
                controller: _controller,
                onPageChanged: (i) => setState(() => _index = i),
                children: [
                  for (final (icon, title, text) in slides)
                    Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(icon, size: 64, color: theme.colorScheme.primary),
                        const SizedBox(height: 16),
                        Text(title, style: theme.textTheme.titleLarge, textAlign: TextAlign.center),
                        const SizedBox(height: 12),
                        Text(text, textAlign: TextAlign.center),
                      ],
                    ),
                ],
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                for (var i = 0; i < slides.length; i++)
                  Container(
                    width: 8,
                    height: 8,
                    margin: const EdgeInsets.symmetric(horizontal: 3),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: i == _index ? theme.colorScheme.primary : theme.colorScheme.outlineVariant,
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                TextButton(onPressed: () => Navigator.of(context).pop(), child: Text(xxd(context, 'Passer'))),
                const Spacer(),
                FilledButton(
                  onPressed: () {
                    if (last) {
                      Navigator.of(context).pop();
                    } else {
                      _controller.nextPage(duration: const Duration(milliseconds: 250), curve: Curves.easeOut);
                    }
                  },
                  child: Text(last ? xxd(context, 'Commencer') : xxd(context, 'Suivant')),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
