import 'package:flutter/material.dart';
import 'package:hiddify/features/home/xxd_i18n.dart';

/// "Comment ça marche ?" dialog (French / English).
void xxdShowHowTo(BuildContext context) {
  showDialog<void>(
    context: context,
    builder: (context) => AlertDialog(
      title: Text(xxd(context, 'Comment ça marche ?')),
      content: SingleChildScrollView(
        child: Text(
          xxd2(
            context,
            "1. Copiez votre identifiant sur l'écran d'accueil et envoyez-le à l'admin (bouton « Envoyer à l'admin »).\n\n"
                '2. Vous recevez un jeton de l\'admin.\n\n'
                '3. Ajoutez un profil, collez le jeton, puis validez.\n\n'
                '4. Appuyez sur le grand bouton pour vous connecter.\n\n'
                '5. Un souci ? Écrivez-nous sur WhatsApp ou Telegram.',
            '1. Copy your ID on the home screen and send it to the admin ("Send to admin" button).\n\n'
                '2. You receive a token from the admin.\n\n'
                '3. Add a profile, paste the token, then confirm.\n\n'
                '4. Tap the big button to connect.\n\n'
                '5. A problem? Write to us on WhatsApp or Telegram.',
          ),
        ),
      ),
      actions: [TextButton(onPressed: () => Navigator.of(context).pop(), child: Text(xxd(context, 'Fermer')))],
    ),
  );
}
