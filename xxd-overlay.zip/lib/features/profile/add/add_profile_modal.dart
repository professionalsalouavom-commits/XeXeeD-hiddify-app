import 'package:flutter/material.dart';
import 'package:hiddify/features/home/xxd_i18n.dart';
import 'package:flutter/services.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:go_router/go_router.dart';
import 'package:hiddify/features/profile/add/widgets/widgets.dart';
import 'package:hiddify/features/profile/model/profile_entity.dart';
import 'package:hiddify/features/profile/notifier/profile_notifier.dart';
import 'package:hiddify/features/profile/xxd_token.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

/// XXD-VPN: the only way to add a profile is the official token (the user's UUID from the panel).
class AddProfileModal extends HookConsumerWidget {
  const AddProfileModal({super.key, this.url});
  final String? url;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    final isLoading = ref.watch(addProfileNotifierProvider).isLoading;
    final controller = useTextEditingController();
    final error = useState<String?>(null);

    ref.listen(addProfileNotifierProvider, (previous, next) {
      if (next case AsyncData(value: final _?)) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (context.mounted && context.canPop()) context.pop();
        });
      }
    });

    Future<void> submit(String raw) async {
      final subUrl = xxdTokenToUrl(raw);
      if (subUrl == null) {
        error.value = xxd2(context, xxdTokenError, 'Invalid token: please enter the official token given by the admin');
        return;
      }
      error.value = null;
      await ref
          .read(addProfileNotifierProvider.notifier)
          .addManual(
            url: subUrl,
            userOverride: UserOverride(name: 'XXD-VPN', isAutoUpdateDisable: false, updateInterval: null),
          );
    }

    // a link opened from outside must be a token too
    useMemoized(() async {
      await Future.delayed(const Duration(milliseconds: 200));
      if (url != null && context.mounted && !isLoading) {
        controller.text = url!;
        await submit(url!);
      }
    });

    return SafeArea(
      child: isLoading
          ? const ProfileLoading()
          : Padding(
              padding: EdgeInsets.fromLTRB(16, 16, 16, 16 + MediaQuery.of(context).viewInsets.bottom),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(xxd(context, 'Importer un jeton'), style: theme.textTheme.titleLarge),
                  const SizedBox(height: 16),
                  TextField(
                    controller: controller,
                    maxLines: 1,
                    autocorrect: false,
                    enableSuggestions: false,
                    decoration: InputDecoration(
                      border: const OutlineInputBorder(),
                      hintText: 'xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx',
                      errorText: error.value,
                      errorMaxLines: 3,
                    ),
                    onSubmitted: submit,
                  ),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton.icon(
                          icon: const Icon(Icons.content_paste_rounded),
                          label: Text(xxd(context, 'Coller')),
                          onPressed: () async {
                            final data = await Clipboard.getData(Clipboard.kTextPlain);
                            controller.text = (data?.text ?? '').trim();
                            error.value = null;
                          },
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: FilledButton(
                          onPressed: () => submit(controller.text),
                          child: Text(xxd(context, 'Valider')),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
    );
  }
}
