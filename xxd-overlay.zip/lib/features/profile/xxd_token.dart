const xxdPrefix = 'XXDVPN-';

// Hiddify Manager subscription link: https://<domain>/<CLIENT_PROXY_PATH>/<user UUID>/auto/
// 1) put your real "client proxy path" below (Hiddify panel -> Settings -> Advanced -> Client proxy path)
// 2) the token a customer receives is the user's UUID (copied from the panel); XXDVPN-<UUID> also works
const xxdSubBase = 'https://xxdvpn.duckdns.org/CLIENT_PROXY_PATH/';
const xxdSubSuffix = '/auto/';

const xxdTokenError =
    'Token invalide : veuillez entrer le jeton officiel fourni par l\'admin';

/// Returns the subscription URL, or null if the token is invalid.
/// The token is the user's UUID from the panel (an optional XXDVPN- in front is accepted and removed).
String? xxdTokenToUrl(String raw) {
  var code = raw.trim();
  if (code.toUpperCase().startsWith(xxdPrefix)) code = code.substring(xxdPrefix.length);
  if (!RegExp(r'^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$').hasMatch(code)) return null;
  return '$xxdSubBase$code$xxdSubSuffix';
}

/// Only subscriptions served by our own panel are accepted.
bool isXxdUrl(String url) => url.startsWith(xxdSubBase);

/// Local (pasted / file) profiles are refused: tokens only.
final bool xxdAllowLocalProfiles = false;
